#!/bin/bash

task=Hopper
#task=HalfCheetah
#task=Walker2d
#task=Ant

envid=My${task}-v2

#array=(0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8)
array=(1.0)

#for((s=0;i<6;i++));do
s=2
    for f in ${array[@]}; do
#	python3 main_train.py --env ${envid} --num-timesteps 0 --num_iters 1000 --batch_episodes 10 --fric_min 0.3 --fric_max 1.6 --outdir ./${task}/fric_${f}/trpo_seed${s}/ --seed $s
	python3 main_train.py --env ${envid} --num-timesteps 0 --num_iters 1000 --batch_episodes 10 --fric_min 1.0 --fric_max 1.0 --outdir ./${task}/fric_${f}/trpo_seed${s}/ --seed $s

    done
#done
