#!/bin/bash

find ./ -name '*progress.csv' -exec python3 temp_plot.py --input {} \;
