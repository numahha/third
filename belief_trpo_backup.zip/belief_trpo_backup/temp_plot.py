import numpy as np
import matplotlib.pyplot as plt
import argparse
#import os


def learning_curve(#x_label_name="EpisodesSoFar",
                   input_filename="progress.csv"):
    with open(input_filename, 'r') as file:
        lines = list(file)
    if len(lines)>0:
        header = lines[0].strip().split(',')
        data = np.loadtxt(lines[1:], delimiter=',')

        if 2==data.ndim:
            #plt.plot(data[:,header.index(x_label_name)],data[:,header.index("EpRewMean")])
            #plt.xlabel(x_label_name)
            iteration= [i+1 for i in range(len(data[:,header.index("EpRewMean")]))]
            plt.plot(iteration,data[:,header.index("EpRewMean")])
            plt.xlabel("Iteration")
            #plt.gca().ticklabel_format(style="sci", scilimits=(0,0), axis="x")
            plt.ylabel('Average Return')
            plt.title(input_filename)
            plt.savefig(input_filename+"_EpRewMean.png")
            plt.close()

            plt.plot(iteration,data[:,header.index("EpLenMean")])
            plt.xlabel("Iteration")
            #plt.gca().ticklabel_format(style="sci", scilimits=(0,0), axis="x")
            plt.ylabel('EpLenMean')
            plt.title(input_filename)
            plt.savefig(input_filename+"_EpLenMean.png")
            plt.close()


if __name__ == '__main__':
    parser=argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--input", type=str)
    args = parser.parse_args()
    print("read ", args.input)
    learning_curve(input_filename=args.input)
