#!/usr/bin/env python3
# noinspection PyUnresolvedReferences
from mpi4py import MPI
from baselines.common.cmd_util import make_mujoco_env, mujoco_arg_parser
from baselines import logger
#from baselines.ppo1.mlp_policy import MlpPolicy
from mlp_policy_belief import MlpPolicy
import custom_trpo_belief
import baselines.common.tf_util as U
import numpy as np
import gym, my_env
import matplotlib.pyplot as plt


def learning_curve(#x_label_name="EpisodesSoFar",
                   input_filename="progress.csv",
                   output_filename="learning_curve.png"):
    with open(input_filename, 'r') as file:
        lines = list(file)
    if len(lines)>0:
        header = lines[0].strip().split(',')
        data = np.loadtxt(lines[1:], delimiter=',')

        if 2==data.ndim:
            #plt.plot(data[:,header.index(x_label_name)],data[:,header.index("EpRewMean")])
            #plt.xlabel(x_label_name)
            iteration= [i+1 for i in range(len(data[:,header.index("EpRewMean")]))]
            plt.plot(iteration,data[:,header.index("EpRewMean")])
            plt.xlabel("Iteration")
            #plt.gca().ticklabel_format(style="sci", scilimits=(0,0), axis="x")
            plt.ylabel('Average Return')
            plt.title(output_filename)
            plt.savefig(output_filename)
            plt.close()
            print("save as", output_filename)

def train(args):
    import baselines.common.tf_util as U
    sess = U.single_threaded_session()
    sess.__enter__()

    rank = MPI.COMM_WORLD.Get_rank()
    if rank == 0:
        logger.configure(args.outdir)
    else:
        logger.configure(format_strs=[])
        logger.set_level(logger.DISABLED)
    workerseed = args.seed + 10000 * MPI.COMM_WORLD.Get_rank()
    def policy_fn(name, ob_space, ac_space):
        return MlpPolicy(name=name, ob_space=ob_space, ac_space=ac_space,
            hid_size=64, num_hid_layers=2)

    logger.log("env_id = ",args.env)
    logger.log("seed = ",args.seed)
    logger.log("indir = ",args.indir)
    logger.log("outdir = ",args.outdir)
    logger.log("batch_episodes = ",args.batch_episodes)
    logger.log("trj_percentile = ",args.trj_percentile)

    env = make_mujoco_env(args.env, workerseed)
    def temp_friction_dist():
        return args.fric_min + (args.fric_max-args.fric_min)*np.random.rand()
    env.env.env.friction_dist = temp_friction_dist
    custom_trpo_belief.learn2(env, policy_fn, timesteps_per_batch=args.batch_steps, episodes_per_batch=args.batch_episodes, 
                              max_kl=0.01, cg_iters=20, cg_damping=0.1,
                              max_iters=args.num_iters, max_timesteps=args.num_timesteps, 
                              #gamma=0.995, lam=0.97, vf_iters=5, vf_stepsize=1e-3, 
                              gamma=1.0, lam=1.0, vf_iters=5, vf_stepsize=1e-3, 
                              input_dir=args.indir, output_dir=args.outdir,
                              trj_percentile=args.trj_percentile)
    env.close()
    learning_curve(input_filename=(args.outdir+"progress.csv"),
                   output_filename=(args.outdir+"progress_curve.eps"))
 
def main():
    parser = mujoco_arg_parser()
    parser.add_argument("--outdir", type=str, default="./outdir/")
    parser.add_argument("--indir", type=str, default=None)
    parser.add_argument("--num_iters", type=int, default=0)
    parser.add_argument("--batch_steps", type=int, default=0)
    parser.add_argument("--batch_episodes", type=int, default=0)
    parser.add_argument("--fric_min", type=float, default=1.0)
    parser.add_argument("--fric_max", type=float, default=1.0)
    parser.add_argument("--trj_percentile", type=int, default=100)
    args = parser.parse_args()
    train(args)

if __name__ == '__main__':
    main()

