#!/bin/bash

fmin=1.0
fmax=1.00
#for((i=1;i<6;i++));do
i=1
    python3 main_test.py --env MyHopper-v2 --fric_min $fmin --fric_max $fmax --indir input/policy${i}/ --outdir temp/
#done
#python3 plot2.py
