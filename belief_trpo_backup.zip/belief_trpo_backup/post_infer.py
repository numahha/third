#!/usr/bin/env python3
# noinspection PyUnresolvedReferences
import matplotlib.pyplot as plt
import numpy as np
import gym, my_env


# currently specialized for Hopper

class PosteriorInference:
    def __init__(self, env_id, sigma=1):
        self.env=gym.make(env_id)
        self.sigma=sigma
        self.gridnum=14 # 14 or 27
        self.fric_grid=np.linspace(0.3, 1.6, self.gridnum)
        self.unnormalized_log_likelihood=np.zeros(self.gridnum)


    def _onestep_pred_error(self, s, ac, snext):
        self.env.env.set_state(s[:6],s[6:])
        ob,r,d,_ = self.env.step(ac)
        return np.sum((snext-self.env.env.state_vector())**2)

    def _traj_pred_error(self, s_list, ac_list):
        tpe=0.
        self.env.reset()
        for i in range(0,len(ac_list)):
            tpe += self._onestep_pred_error(s_list[i], ac_list[i], s_list[i+1])
        return tpe


    def _log_likelihood_for_fric(self, fric_input, s_list, ac_list):
        def temp_friction_dist():
            return fric_input
        self.env.env.friction_dist = temp_friction_dist
        return -self._traj_pred_error(s_list, ac_list)

    def update(self, s_list, ac_list):
        for i in range(0,self.gridnum):
            self.unnormalized_log_likelihood[i] += self._log_likelihood_for_fric( self.fric_grid[i], s_list, ac_list)

    def grid_dist(self):
        normalization_constant=0.
        for i in range(0,self.gridnum):
            normalization_constant+=np.exp(self.unnormalized_log_likelihood[i]/(2.*self.sigma))
        return np.exp(self.unnormalized_log_likelihood/(2.*self.sigma))/normalization_constant

    def grid_dist_feature(self):
        temp_dist=self.grid_dist()
        return np.array([temp_dist[0], temp_dist[3], temp_dist[7], temp_dist[11], temp_dist[13]])

    def reset_infer(self):
        self.unnormalized_log_likelihood=np.zeros(self.gridnum)

    '''
    def traj_error_plot(self, s_list, ac_list, path):
        for f in [1.0, 0.3, 1.6]:
            def temp_friction_dist():
                return f
            self.env.env.friction_dist = temp_friction_dist
            self.env.reset()
            x=[]
            t=[]
            tpe=0.
            for i in range(0,len(ac_list)):
                t.append(i)
                tpe += self._onestep_pred_error(s_list[i], ac_list[i], s_list[i+1])
                x.append(tpe)
            plt.plot(t, x,label="estimate_theta ="+('%2.2f' % f ))
        plt.legend()
        plt.xlabel('timesteps')
        plt.ylabel('cummurative squared error')     
        plt.xlim([0, 1000])   
        plt.title(path+'error_traj.eps')
        plt.savefig(path+'error_traj.eps')
        plt.close()

    def mean_and_variance(self):
        post_grid_dist=self.grid_dist()
        post_mean=np.dot(post_grid_dist,self.fric_grid)
        x=0.
        for i in range(0,self.gridnum):
            x+=((self.fric_grid[i]-post_mean)**2)*post_grid_dist[i]
        return post_mean, x

    def coverage(self):
        post_grid_dist=self.grid_dist()
        p=np.zeros(3)
        for i in range(0,self.gridnum):
            if 0.6 < (self.fric_grid[i]+1.0e-6) and 1.4 > (self.fric_grid[i]-1.0e-6):
                p[0]+=post_grid_dist[i]
            if  0.6 > (self.fric_grid[i]-1.0e-6):
                p[1]+=post_grid_dist[i]
            if 1.4 < (self.fric_grid[i]+1.0e-6):
                p[2]+=post_grid_dist[i]
        return p

    def coverage2(self):
        post_grid_dist=self.grid_dist()
        p=np.zeros(5)
        for i in range(0,self.gridnum):
            if 0.6 < (self.fric_grid[i]+1.0e-6) and 1.4 > (self.fric_grid[i]-1.0e-6):
                p[0]+=post_grid_dist[i]
            if  0.6 > (self.fric_grid[i]-1.0e-6):
                p[1]+=post_grid_dist[i]
            if 1.4 < (self.fric_grid[i]+1.0e-6):
                p[2]+=post_grid_dist[i]
            if  0.4 > (self.fric_grid[i]-1.0e-6):
                p[3]+=post_grid_dist[i]
            if 0.4 < (self.fric_grid[i]+1.0e-6) and 0.6 > (self.fric_grid[i]-1.0e-6):
                p[4]+=post_grid_dist[i]
        return p

    def save_posterior_plot(self, path, rAll):

        for i in [1, 4, 16, 64, 256, 1024]:
            self.sigma=i
            plt.plot(self.fric_grid,self.grid_dist(),label="sigma ="+('%d' % self.sigma ))
        plt.legend()
        plt.xlabel('Friction')
        plt.ylabel('normalized grid posterior')
        plt.title(path+'grid_post.eps   EpRew ='+('%3.3f' % rAll ))
        plt.savefig(path+'grid_post.eps')
        plt.close()
        
        x=np.linspace(0.3, 1.6, 200)
  
        for i in [1, 4, 16, 64, 256, 1024]:
            self.sigma=i
            mean, var = self.mean_and_variance()
            def temp_norm_dens(x):
                return np.exp(-(x-mean)**2/(2.*var)) / np.sqrt(2.*np.pi*var)
        
            y=[]
            for j in range(0,200):
                y.append(temp_norm_dens(x[j]))
            plt.plot(x,y,label="sigma ="+('%d' % self.sigma ))
        plt.legend()
        plt.xlabel('Friction')
        plt.ylabel('Gauss-approximate posterior')
        plt.title(path+'gauss_post.eps   EpRew ='+('%3.3f' % rAll ))
        plt.savefig(path+'gauss_post.eps')
        plt.close()
    '''

