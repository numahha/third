from my_env.hopper import MyHopperEnv1
from my_env.half_cheetah import MyHalfCheetahEnv1
from my_env.walker2d import MyWalker2dEnv1
from my_env.ant import MyAntEnv1
from my_env.humanoid import MyHumanoidEnv1

#from gym.envs.registration import registry, register, make, spec
from gym.envs.registration import register

register(
    id='MyHopper-v2',
    entry_point='my_env:MyHopperEnv1',
    max_episode_steps=1000,
    reward_threshold=3800.0,
)

register(
    id='MyHalfCheetah-v2',
    entry_point='my_env:MyHalfCheetahEnv1',
    max_episode_steps=1000,
    reward_threshold=4800.0,
)


register(
    id='MyWalker2d-v2',
    max_episode_steps=1000,
    entry_point='my_env:MyWalker2dEnv1',
)

register(
    id='MyAnt-v2',
    max_episode_steps=1000,
    entry_point='my_env:MyAntEnv1',
    reward_threshold=6000.0,
)

register(
    id='MyHumanoid-v2',
    entry_point='my_env:MyHumanoidEnv1',
    max_episode_steps=1000,
)
