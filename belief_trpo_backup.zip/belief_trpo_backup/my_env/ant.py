import os

import numpy as np
from gym import utils
from gym.envs.mujoco import MujocoEnv, AntEnv


class MyAntEnv1(AntEnv):
    def __init__(self, xml_filename="ant.xml"):
        print("\n[  Start print in __init___ in MyAntEnv1  ]")
        utils.EzPickle.__init__(self)
        assets_path = os.path.join(os.path.dirname(__file__), "assets")
        xml_path = os.path.join(assets_path, xml_filename)
        MujocoEnv.__init__(self, xml_path, 5)
        print("xml_filename is ",xml_filename) # add
        print("body_mass is ",self.sim.model.body_mass) # add
        print("geom_friction is ",self.sim.model.geom_friction) # add
        print("[  End print in __init___ in MyAntEnv1  ]\n") # add
        self.default_body_mass=np.copy(self.sim.model.body_mass) # add
        self.default_geom_friction=np.copy(self.sim.model.geom_friction) # add
        self.torso_mass_dist=None # add
        self.friction_dist=None # add
        self.friction_coeff=1. # add 

        
    def reset_model(self):
        if self.torso_mass_dist is not None: # add
            self.sim.model.body_mass[1] = self.torso_mass_dist() # add
        if self.friction_dist is not None: # add
            self.friction_coeff=self.friction_dist() # add 
            for i in range(0, len(self.sim.model.geom_friction)): # add
                self.sim.model.geom_friction[i,0] = self.default_geom_friction[i,0]*self.friction_coeff # add
                self.sim.model.geom_friction[i,1] = self.default_geom_friction[i,1]*self.friction_coeff # add
                self.sim.model.geom_friction[i,2] = self.default_geom_friction[i,2]*self.friction_coeff # add
        qpos = self.init_qpos + self.np_random.uniform(size=self.model.nq, low=-.1, high=.1)
        qvel = self.init_qvel + self.np_random.randn(self.model.nv) * .1
        self.set_state(qpos, qvel)
        return self._get_obs()

